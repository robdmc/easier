# SQL Commenting Guidelines

**When to apply:** Only apply these guidelines when the user explicitly asks to document or comment SQL. Otherwise, use your normal judgment.

**Core principle:** Explain *why*, not *what*. Focus on business logic and edge cases.

## When to comment

- Aggregation choice has semantic meaning (why MAX vs MIN vs ANY_VALUE?)
- Handling edge cases (NULLs, duplicates, date boundaries)
- CTE purpose isn't obvious from its name and code
- Complex joins or filtering logic that embodies business rules

## When to skip comments

- The code is self-explanatory
- You're restating what the SQL already says
- Simple queries with obvious intent

## Examples

**Bad:** `-- Use MAX on stripe_customer_id`

**Good:** `-- MAX prefers non-NULL, so we get the Stripe ID once assigned`

**Bad:** `-- Join users to orders`

**Good:** `-- Inner join excludes users who never ordered (intentional for active-user analysis)`

## For complex queries

A brief header explaining the overall approach is helpful:

```sql
-- Reconstruct subscription periods from profile_history snapshots
-- by detecting when account_active_through changes
WITH ...
```

## CTE documentation

Every CTE should have structured headers explaining its purpose:

```sql
-- Problem: Multiple snapshots per day create duplicates
-- Solution: Keep only the last snapshot per profile per day
-- Why: We only care about end-of-day state
WITH deduplicated AS (
    SELECT *, ROW_NUMBER() OVER (
        PARTITION BY profile_id, DATE(history_date)
        ORDER BY history_date DESC
    ) as day_row
    FROM profile_history
)
```

This structure forces you to articulate *why* each transformation step exists, not just what it does.

## Context that helps (when known)

Include these when relevant:

- **Schema semantics**: What columns actually mean (`account_active_through` is paid-through date, not expiration)
- **Expected output shape**: What each row represents ("one row per subscription period")
- **Data quirks**: Known issues or edge cases ("data before 2020 has inconsistent stripe IDs")
